<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Viitamismoodus';
$lang_plugin_link_target['description'] = 'Muudab moodust, kuidas väliseid linke avatakse: kui plugin on lubatud, siis kõik atribuutidega rel="external" lingid avatakse uues aknas (samas aknas avamise asemel).';
$lang_plugin_link_target['extra'] = 'See plugin avaldab mõju galerii allosas olevale "Powered by Coppermine" lingile.';
$lang_plugin_link_target['recommendation'] = 'Seda pluginat pole soovitav kasutada, et ära hoida kasutajate eemaletõukamist: uues aknas lingi avamine tähendab oma külastajatega ülbitsemist.';
