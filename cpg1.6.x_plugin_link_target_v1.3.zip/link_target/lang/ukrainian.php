<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Тип посилань';
$lang_plugin_link_target['description'] = 'Змінює механізм відкриття зовнішніх сссилок: коли даний плагін включений, всі посилання, які містять атребут rel = &quot;external&quot;, будуть відкриватися в новому вікні (замість того ж вікна).';
$lang_plugin_link_target['extra'] = 'Цей доданок має вплив в основному на посилання &quot;Powered by Coppermine&quot; внизу сторінки.';
$lang_plugin_link_target['recommendation'] = 'Рекомендується не використовувати цей плагін, щоб уникнути командування Вашими користувачам: відкриття посилання в новому вікні означає командування Вашими відвідувачами сайту.';
