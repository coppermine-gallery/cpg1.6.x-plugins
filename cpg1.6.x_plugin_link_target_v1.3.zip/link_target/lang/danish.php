<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Link target';
$lang_plugin_link_target['description'] = 'Ændre måden eksterne links åbnes: Når dette plugin er slået til, vil alle links der indeholder attributen rel="external" åbne i et nyt vindue (istedet for i samme vindue).';
$lang_plugin_link_target['extra'] = 'Dette plugin påvirker for det meste "Powered by Coppermine" linket i bunden af galleri siden.';
$lang_plugin_link_target['recommendation'] = 'Det anbefales ikke at bruge dette plugin for at genere dine brugere: Åbne links i nye vinduer genere dine brugere.';
