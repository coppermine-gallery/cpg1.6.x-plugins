<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Linkin kohde';
$lang_plugin_link_target['description'] = 'Muuttaa ulkoisten linkkien avaamistapaa: kun lisäosa on käytössä, kaikki linkit, jotka sisältävät määritelmän rel="external", avataan uudessa ikkunassa (saman ikkunan sijaan).';
$lang_plugin_link_target['extra'] = 'Tämä lisäosa vaikuttaa lähinnä "Powered by Coppermine" linkkiin gallerian alalaidassa.';
$lang_plugin_link_target['recommendation'] = 'On suositeltavaa olla käyttämättä tätä lisäosaa välttääksesi käyttäjiesi ohjaamista muualle: linkkien avaaminen uuteen ikkunaan tarkoittaa käyttäjiesi ohjaamista sivustolla.';
