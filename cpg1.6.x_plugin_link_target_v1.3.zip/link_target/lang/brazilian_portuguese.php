<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Link  de destino';
$lang_plugin_link_target['description'] = 'Altera a forma em que os links externos são abertos: quando este plugin está ativo, todos os links que contenham o atributo rel="external" serão abertos numa nova janela.';
$lang_plugin_link_target['extra'] = 'Este plugin funciona, principalmente, no link "Powered by Coppermine" no rodapé da página da galeria.';
$lang_plugin_link_target['recommendation'] = 'É recomendado não usar este plugin para controlar os usuários: abrindo links em novas janelas é considerado uma forma de tentar controlar os usuários.';
