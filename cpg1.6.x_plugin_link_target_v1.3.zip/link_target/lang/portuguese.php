<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Destino do link';
$lang_plugin_link_target['description'] = 'Altera a forma em que os links externos são abertos: quando este plugin está activo, todos os links que contenham o atributo rel="external" serão abertos numa nova janela (em vez de serem abertos na mesma).';
$lang_plugin_link_target['extra'] = 'Este plugin tem impacto, principalmente, no link "Powered by Coppermine" no rodapé da página da galeria.';
$lang_plugin_link_target['recommendation'] = 'É recomendado que não use este plugin para controlar os seus utilizadores: abrindo links em novas janelas é considerado uma forma de tentar controlar os utilizadores.';
