<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Destino del enlace';
$lang_plugin_link_target['description'] = 'Cambia la manera de abrir de los enlaces: cuando se habilita, los encaes con el atributo rel="external" se abrirán en ventana nueva (en lugar de ser la misma ventana).';
$lang_plugin_link_target['extra'] = 'Sobre todo tendrá impacto en los enlaces "Powered by Coppermine" en la parte baja de la página de la galería.';
$lang_plugin_link_target['recommendation'] = 'No es recomendable usar el plugin para evitar controlar a tus usuarios: abrir enlaces en nuevas ventanas es una forma de mangonear a los visitantes.';
