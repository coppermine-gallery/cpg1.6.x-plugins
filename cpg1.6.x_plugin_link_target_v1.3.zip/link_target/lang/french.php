<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Cible du lien';
$lang_plugin_link_target['description'] = 'Change la manière dont les liens externes sont ouverts : si ce plugin est activé, tous les liens contenant l\'attribut rel="external" seront ouverts dans une nouvelle fenêtre (au lieu de la même).';
$lang_plugin_link_target['extra'] = 'Ce plugin a surtout un impact sur le lien &quot;Powered by Coppermine&quot; au bas de l\'écran de la galerie.';
$lang_plugin_link_target['recommendation'] = 'Il n\'est pas recommandé d\'utiliser ce plugin pour être directif avec vos visiteurs : ouvrir un lien dans une nouvelle fenêtre peut être directif pour vos visiteurs.';
