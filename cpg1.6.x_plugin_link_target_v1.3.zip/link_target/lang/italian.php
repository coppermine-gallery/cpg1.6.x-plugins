<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Destinazione del collegamento';
$lang_plugin_link_target['description'] = 'Modifica il modo con cui vengono aperti i collegamenti esterni: quando questo plugin &egrave; abilitato, tutti i collegamenti che contengono l\'attributo \'rel="external"\' si apriranno in una nuova finestra (anzich&egrave; nella stessa).';
$lang_plugin_link_target['extra'] = 'Questo plugin incide soprattutto sul collegamento "Powered by Coppermine" in fondo alle pagine della galleria.';
$lang_plugin_link_target['recommendation'] = '&Egrave; consigliato di non usare questo plugin per evitare imposizioni arbitrarie ai tuoi utenti: aprire i collegamenti in una nuova finestra &egrave; un\'imposizione arbitraria.';
