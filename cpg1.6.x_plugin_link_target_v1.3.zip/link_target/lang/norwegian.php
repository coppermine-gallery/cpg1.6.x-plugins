<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Link';
$lang_plugin_link_target['description'] = 'Endrer måten som eksterne linker åpnes på: når denne plugin-modulen aktiveres, kommer alle linker til å bli åpnet i et nytt vindu (i stedet for i samme vindu).';
$lang_plugin_link_target['extra'] = 'Denne pluginnmodul påvirker mest "Powered by Coppermine" linken nederst på siden.';
$lang_plugin_link_target['recommendation'] = 'Det anbefales å ikke bruke denne plugin-modulen, da brukerne opplever det slitsomt når hver link åpnes i et nytt vindu.';
