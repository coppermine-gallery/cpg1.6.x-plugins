<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'لینک هدف ';
$lang_plugin_link_target['description'] = 'تغییر روش لینک‌های خارجی در حال باز شدن:  زمانی که این پلاگین را فعال کنید، تمام لینک‌هایی خارجی در یک پنجره جدید (به جای همان پنجره)
باز می‌شوند .';
$lang_plugin_link_target['extra'] = 'این پلاگین دارای تاثیر زیادی روی لینک «Powered by Coppermine» در پایین خروجی گالری می‌باشد.';
$lang_plugin_link_target['recommendation'] = 'توصیه می‌شود برای جلوگیری از مجبور کردن کاربران‌تان از این پلاگین استفاده نکنید. باز شدن لینک‌ها در پنجره جداگانه به معنای مجبور کردن بازدیدکنندگان سایتتان است.';
