<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Link target';
$lang_plugin_link_target['description'] = 'Ändert die Art, in der externe Links geöffnet werden: wenn dieses Plugin aktiviert ist werden alle Links, die das Attribute rel="external" tragen in einem neuen Fenster geöffnet (anstelle des gleichen Fensters).';
$lang_plugin_link_target['extra'] = 'Dieses Plugin hat hauptsächlich Auswirkungen auf den "Powered by Coppermine" Verweis ganz unten auf der Seite.';
$lang_plugin_link_target['recommendation'] = 'Es wird empfohlen, dieses Plugin nicht zu benutzen, um die Besucher der Galerie nicht unnötig zu bevormunden.';
