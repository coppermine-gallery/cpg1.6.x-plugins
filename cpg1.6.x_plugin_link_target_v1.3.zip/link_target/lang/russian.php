<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Тип ссылок';
$lang_plugin_link_target['description'] = 'Изменяет механизм открытия внешних сссылок: когда данный плагин включен, все ссылки, которые содержат атрибут rel="external", будут открыавться в новом окне (вместо того же окна).';
$lang_plugin_link_target['extra'] = 'Этот плагин имеет влияние в основном на ссылку "Powered by Coppermine" внизу страницы.';
$lang_plugin_link_target['recommendation'] = 'Рекомендуется не использовать этот плагин, чтобы избежать командования Вашими пользователям: открытие ссылки в новом окне означает командование Вашими посетителями сайта.';
