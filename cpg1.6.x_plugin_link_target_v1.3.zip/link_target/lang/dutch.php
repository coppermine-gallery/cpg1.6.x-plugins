<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Link het doel';
$lang_plugin_link_target['description'] = 'Verandert de manier waarop externe linken geopend worden: wanneer deze plugin ingeschakeld is, zullen alle linken die het attribuut rel="external" openen in een nieuw venster (inplaats van hetzelfde venster).';
$lang_plugin_link_target['extra'] = 'Deze plugin heeft het grootste impact op de "Powered by Coppermine" link onderaan de gallery output.';
$lang_plugin_link_target['recommendation'] = 'Het is aanbevolen om deze plugin niet te gebruiken om te voorkomen dat jouw gebruikers naar her en der gestuurd worden: het openen van linken in een nieuw venster betekent het weg en weer sturen van je gebruikers.';
