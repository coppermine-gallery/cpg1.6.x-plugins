<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Link target';
$lang_plugin_link_target['description'] = 'Breytir því hvernig slóðir annað eru opnaðar: þegar þessi viðbót er virkjuð, allar slóðir sem innihalda rel="external" munu opnast í nýjum glugga (í stað sama glugga).';
$lang_plugin_link_target['extra'] = 'This plugin has an impact mostly on the "Powered by Coppermine" link at the bottom of the gallery output.';
$lang_plugin_link_target['recommendation'] = 'Það er ráðlegt að nota ekki þessa viðbótu svo þú sért ekki að stjórna gestu/notendum: að opna slóð í nýjum guggar er stjórnun á gestum/notendum.';
