<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Otvaranje veza';
$lang_plugin_link_target['description'] = 'Menja način na koji se otvaraju spoljne veze: kad je ovaj dodatak uključen, sve veze koje sadrže atribut rel="external" otvoriće se u novom prozoru (umesto u istom prozoru).';
$lang_plugin_link_target['extra'] = 'Ovaj dodatak uglavnom utiče na "Powered by Coppermine" vezu na dnu sadržaja galerije.';
$lang_plugin_link_target['recommendation'] = 'Preporučuje se da ne koristite ovaj dodatak kako biste izbegli da se ponašate zapovednički prema korisnicima: otvaranje linkova u novom prozoru predstavlja zapovedničko ponašanje prema korisnicima.';
