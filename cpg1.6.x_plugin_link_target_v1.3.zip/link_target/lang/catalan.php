﻿<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = 'Destinació de l\'enllaç' ;
$lang_plugin_link_target['description'] = 'Canvia la manera d\'obrir dels enllaços: quan s\'habilita, els enllaços amb l\'atribut rel="external" s\'obriran en una altra finestra (en lloc de ser la mateixa finestra).';
$lang_plugin_link_target['extra'] = 'Sobretot tindrà impacte en els enllaços "Powered by Coppermine" a la part baixa de la pàgina de la galeria.';
$lang_plugin_link_target['recommendation'] = 'No és recomanable fer servir el plugin per evitar controlar als teus usuaris: obrir enllaços en noves finestres és una forma de manipular als visitants.';
