<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_link_target['name'] = '链接目标';
$lang_plugin_link_target['description'] = '更改外部链接正在开放的方式：当这个插件启用时，所有的链接，包含属性为 rel="external" 会打开一个新窗口（而不是在同一窗口）。';
$lang_plugin_link_target['extra'] = '此插件有一个关于"Powered by Coppermine" 底部链接的影响。';
$lang_plugin_link_target['recommendation'] = '建议不要使用这个插件， 以避免阻止用户打开在新窗口链接方式阻止您的网站访问者。';
