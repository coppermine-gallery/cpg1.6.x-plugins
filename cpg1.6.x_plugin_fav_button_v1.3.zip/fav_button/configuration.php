<?php
/*********************************************
  Coppermine Plugin - Favorite Button
  ********************************************
  Copyright (c) 2009-2018 eenemeenemuu
**********************************************/

$name = 'Favorite Button';
$description = 'Adds a button to the navigation menu to easily add/remove pictures to/from your favorites';
$author = '<a href="http://forum.coppermine-gallery.net/index.php?action=profile;u=24278" rel="external" class="external">eenemeenemuu</a>';
$version = '1.3';
$plugin_cpg_version = array('min' => '1.5');
$extra_info = $install_info = '<a href="http://forum.coppermine-gallery.net/index.php/topic,79582.0.html" rel="external" class="admin_menu">'.cpg_fetch_icon('announcement', 1).'Announcement thread</a>';

//EOF