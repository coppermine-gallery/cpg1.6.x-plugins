<?php
/**************************************************
  Coppermine 1.6.x Plugin - Problem Solving CAPTCHA
  *************************************************
  Copyright (c) 2013-2019 eenemeenemuu
**************************************************/

if (!defined('IN_COPPERMINE')) {
    die('Not in Coppermine...');
}

$lang_plugin_problem_solving_captcha['problem_solving_captcha'] = 'Problemlösungs-CAPTCHA';
$lang_plugin_problem_solving_captcha['description'] = 'Erstelle eigene Fragen, die deine Benutzer beantworten müssen';
$lang_plugin_problem_solving_captcha['announcement_thread'] = 'Ankündigungs-Thema';
$lang_plugin_problem_solving_captcha['question'] = 'Frage';
$lang_plugin_problem_solving_captcha['answer'] = 'Antwort';

//EOF