<?php
/**************************************************
  Coppermine 1.6.x Plugin - Random File Name Suffix
  *************************************************
  Copyright (c) 2011-2019 eenemeenemuu
**************************************************/

$name = 'Random File Name Suffix';
$description = 'Adds a random suffix to the file name during upload';
$author='eenemeenemuu';
$version='0.1';
$plugin_cpg_version = array('min' => '1.5.42');

//EOF