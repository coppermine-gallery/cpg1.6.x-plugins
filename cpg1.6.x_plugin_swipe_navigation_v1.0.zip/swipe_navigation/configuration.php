<?php
/*********************************************
  Coppermine Plugin - Swipe Navigation
  ********************************************
  Copyright (c) 2022 eenemeenemuu
**********************************************/

$name = 'Swipe Navigation';
$description = 'Navigate to the previous/next picture or thumbnail page via swipe gesture';
$author = '<a href="http://forum.coppermine-gallery.net/index.php?action=profile;u=24278" rel="external" class="external">eenemeenemuu</a>';
$version = '1.0';
$plugin_cpg_version = array('min' => '1.5');
$extra_info = $install_info = '<a href="http://forum.coppermine-gallery.net/index.php/topic,80564.0.html" rel="external" class="admin_menu">'.cpg_fetch_icon('announcement', 1).'Announcement thread</a>';

//EOF
