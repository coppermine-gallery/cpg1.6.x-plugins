<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_opensearch['config_name'] = 'OpenSearch';
$lang_plugin_opensearch['config_description'] = '<a href="http://www.opensearch.org/" rel="external" class="external">OpenSearch</a>:in implementaatio Copperminelle.<br />Kun lisäosa on käytössä, käyttäjät voivat lisätä galleriasi heidän selaimensa hakupalkkiin.';
$lang_plugin_opensearch['search'] = 'Hae %s';
$lang_plugin_opensearch['extra'] = 'Voit halutessasi lisätä sivustollesi tekstiä, joka kertoo mitä tämä lisäosa tekee';
$lang_plugin_opensearch['failed_to_open_file'] = 'Tiedoston %s avaus ';
$lang_plugin_opensearch['failed_to_write_file'] = 'Tiedostoon %s kirjoittaminen epäonnistui - tarkista oikeudet';
$lang_plugin_opensearch['form_header'] = 'Syötä käytettävät tiedot kuvaus -tiedostoa varten';
$lang_plugin_opensearch['gallery_url'] = 'Gallerian URL (pitää olla oikein)';
$lang_plugin_opensearch['display_name'] = 'Selaimessa näytettävä nimi';
$lang_plugin_opensearch['description'] = 'Kuvaus';
$lang_plugin_opensearch['character_limit'] = '%s merkin rajoitus';
