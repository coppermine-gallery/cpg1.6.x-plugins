<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_opensearch['config_name'] = '开放式搜索';
$lang_plugin_opensearch['config_description'] = '当启用时<a href="http://www.opensearch.org/" rel="external" class="external">OpenSearch</a> for Coppermine.<br />，访问者可以添加您的画廊他们的浏览器的搜索栏。';
$lang_plugin_opensearch['search'] = '搜索%s';
$lang_plugin_opensearch['extra'] = '您可能需要添加一些文本到您的网站，解释这个插件';
$lang_plugin_opensearch['failed_to_open_file'] = '无法打开文件 %s -  检查权限';
$lang_plugin_opensearch['failed_to_write_file'] = '无法写入文件 %s - 检查权限';
$lang_plugin_opensearch['form_header'] = '输入细节用于描述文件';
$lang_plugin_opensearch['gallery_url'] = '画廊网址（必须是正确的）';
$lang_plugin_opensearch['display_name'] = '名称在浏览器中显示';
$lang_plugin_opensearch['description'] = '描述';
$lang_plugin_opensearch['character_limit'] = '%s 字数限制';
