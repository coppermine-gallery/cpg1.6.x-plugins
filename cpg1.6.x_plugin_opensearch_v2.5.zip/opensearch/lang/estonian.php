<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_opensearch['config_name'] = 'OpenSearch';
$lang_plugin_opensearch['config_description'] = '<a href="http://www.opensearch.org/" rel="external" class="external">OpenSearch\'i</a> rakendus Coppermine\'ile.<br />Kui lubatud, siis saavad külastajad lisada sinu galerii oma brauseri otsinguribale.';
$lang_plugin_opensearch['search'] = 'Otsida: %s';
$lang_plugin_opensearch['extra'] = 'Soovid ehk lisada natuke teksti oma saidile, mis selgitab, mida see plugin teeb';
$lang_plugin_opensearch['failed_to_open_file'] = 'Faili %s avamine ebaõnnestus - kontrolli õigusi';
$lang_plugin_opensearch['failed_to_write_file'] = 'Faili %s kirjutamine ebaõnnestus - kontrolli õigusi';
$lang_plugin_opensearch['form_header'] = 'Sisesta üksikasjad, mida kasutatakse kirjeldavas failis';
$lang_plugin_opensearch['gallery_url'] = 'Galerii URL (kontrolli töötavust)';
$lang_plugin_opensearch['display_name'] = 'Nimi nagu seda brauseris näidatakse';
$lang_plugin_opensearch['description'] = 'Kirjeldus';
$lang_plugin_opensearch['character_limit'] = '%s tähemärgi limiit';
