<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$name = $lang_plugin_html5slideshow['html5slide'];
$description = $lang_plugin_html5slideshow['plug_desc'];
$author = 'Ron Crans';
$version = '1.4.2';
$plugin_cpg_version = array('min' => '1.6');
$install_info = $lang_plugin_html5slideshow['plug_info'];
$config_action = 'config';
