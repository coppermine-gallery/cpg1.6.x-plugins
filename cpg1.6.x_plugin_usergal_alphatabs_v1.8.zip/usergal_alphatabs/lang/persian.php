<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'زبانه‌های الفبایی گالری کاربران';
$lang_plugin_usergal_alphatabs['config_description'] = 'آنچه انجام می‌دهد: نمایش زبانه‌ها از A  تا Z در بالای گالری کاربران برای آنکه بازدیدکنندگان بتوانند با کلیک روی یک حرف مستقیما به صفحه‌ای که تمام گالری‌های کاربرانی را نمایش می‌دهد که شناسه کاربری‌شان با آن حرف شروع می‌شود بروند. نصب این پلاگین فقط اگر تعداد واقعا بسیاری گالری‌های کاربری داریدتوصیه می‌شود.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'انتخاب بر اساس نام کاربری';
