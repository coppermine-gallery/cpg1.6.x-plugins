<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'Abas Alfabéticas de Galerias de Usuários';
$lang_plugin_usergal_alphatabs['config_description'] = 'Apresenta abas de A a Z no topo das galerias de usuário onde visitantes podem clicar para saltar diretamente para uma página que mostra todas as galerias dos usuários cujo nome comece por essa letra. Este plugin só é recomendado para quem tem um grande número de galerias de usuário';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Saltar por nome de usuário';
