<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'Brukergalleri alfabetiske faner';
$lang_plugin_usergal_alphatabs['config_description'] = 'Hvad det gjør: viser faner fra A til Z øverst på brukergallierier som gjester kan klikk på for å komme direkte til en side som bare viser alle gallerier som tillhører brukere med navn som begynner med den valgte bokstaven. Plugin-modulen anbefales bare om du har et stort antall brukergallerier.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Hopp til brukernavn';
