<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'Abecedne kartice sa korisničkim galerijama';
$lang_plugin_usergal_alphatabs['config_description'] = 'Šta ovo radi: prikazuje kartice od A do Z na vrhu korisničkih galerija na koje korisnici mogu da kliknu i direktno se prebace na stranicu koja prikazuje sve korisničke galerije korisnika čije korisničko ime počinje tim slovom. Preporučuje se da koristite dodatak ako imate veoma veliki broj korisničkih galerija.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Prebacivanje po korisničkom imenu';
