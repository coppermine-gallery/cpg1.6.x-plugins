﻿<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'Pestanyes alfabètiques de galeries d\'usuaris';
$lang_plugin_usergal_alphatabs['config_description'] = 'Què fa: mostra les fitxes de l\'A a la Z a la part superior de les galeries en que els visitants poden fer clic i anar directament a una pàgina que mostra totes les galeries dels usuaris en que el nom d\'usuari comença per aquesta lletra. Aquest Plugin només es recomana per ser utilitzat si vostè té un molt gran nombre de galeries d\'usuari.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Saltar per nom d\'usuari';
