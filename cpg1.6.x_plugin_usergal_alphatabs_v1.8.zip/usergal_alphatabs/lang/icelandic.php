<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'User Gallery Alphabetic Tabbing';
$lang_plugin_usergal_alphatabs['config_description'] = 'Hvað hún gerir: sýnir stafrófið fyrir ofan notendasöfn og gestir/notendur geta smellt á staf og farið beint í notendur sem byrja á þeim staf. Viðbót sem er aðeins ráðlegt að nota ef það eru margir notendur að safninu.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Leita að notanda';
