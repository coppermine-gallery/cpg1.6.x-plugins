<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'Pestañas alfabéticas de galerías de usuarios';
$lang_plugin_usergal_alphatabs['config_description'] = 'Qué hace: muestra pestañas de la A a la Z sobre las galerías de usuario en las que pulsar y saltar a una página que muestra las galerías de los usuarios cuyo nombre empieza por esa letra. Recomendado sólo si tienes muchas galerías de usuario.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Saltar por nombre de usuario';
