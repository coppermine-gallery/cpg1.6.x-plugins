<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'Bruger Galleri Alfabetisk Faneblads opdelt';
$lang_plugin_usergal_alphatabs['config_description'] = 'Hvad det gør: Viser  faner fra A til Z i toppen af Bruger galleriet hvor besøgende kan klikke og hoppe direkt til en side som viser alle bruger gallerier der starter med dette bogstav. Plugin kun anbefalet og bruge hvis du har mange bruger gallerier.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Hop til brugernavn';
