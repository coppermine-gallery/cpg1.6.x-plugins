<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'ألسنة أبجدية لألبوم العضو';
$lang_plugin_usergal_alphatabs['config_description'] = 'ماذا تعمل: تعرض ألسنة من A إلى Z في أعلى ألبومات العضو يمكن للزوار النقر عليها للذهاب مباشرة للصفة التي تعرض جميع ألبومات العضو للأعضاء الذين تبدأ أسمائهم بذلك الحرف. الإضافة البرمجية ينصح بها فقط اذا كان هناك عدد كبير من ألبومات العضو.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'الذهاب عن طريق اسم العضو';
