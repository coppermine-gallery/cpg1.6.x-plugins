<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'Användargalleri alfabetiska flikar';
$lang_plugin_usergal_alphatabs['config_description'] = 'Vad det gör: visar flikar från A till Z överst på användargallierier som besökare kan klicka för att komma direkt till en sida som bara visar alla gallerier som tillhör användare vars namn börjar på den valda bokstaven. Insticksmodulen rekommenderas bara om du har ett stort antal användagallerier.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Hoppa med användarnamn';
