<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'User Gallery Alphabetic Tabbing';
$lang_plugin_usergal_alphatabs['config_description'] = 'What it does: displays tabs from A to Z at the top of user galleries that visitors can click on to directly jump to a page that displays all user galleries of the users who\'s username starts with that letter. Plugin only recommended to be used if you have a really large number of user galleries.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Jump by username';
