<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'User Gallery Alphabetic Tabbing(Onglets alphabétiques pour les galeries utilisateurs)';
$lang_plugin_usergal_alphatabs['config_description'] = 'Ce qu\'il fait : il affiche des onglets alphabétiques en haut du cadre des galeries utilisateurs afin que les visiteurs puissent accéder directement vers une page qui affiche toutes les galeries utilisateur dont le nom commence par la lettre sur laquelle il a cliqué. Ce plugin est recommandé si vous avez réellement un très grand nombre de galeries utilisateurs.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Naviguer par nom d\'utilisateur';
