<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'User Gallery Alphabetic Tabbing (ユーザギャラリーのアルファベットタブ)';
$lang_plugin_usergal_alphatabs['config_description'] = '何をするのか?: ユーザギャラリーの上部にA～Zのタブを表示します。タブをクリックすることで、その文字で始まるユーザ名のユーザギャラリーすべてを表示して、訪問者が直接ジャンプできるようにします。あなたが膨大な数のユーザを登録している場合のみ、このプラグインの使用をお勧めします。';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'ユーザ名にジャンプする';
