<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = '用艺术馆字母键';
$lang_plugin_usergal_alphatabs['config_description'] = '您能做些什么：从A用户在画廊前到Z，游客可以点击显示选项卡上，直接跳转到一个页面，显示所有用户的用户展厅谁的用户名启动以该字母。，如果你是一个真正的大量用户的建议使用。';
$lang_plugin_usergal_alphatabs['jump_by_username'] = '跳转的用户名';
