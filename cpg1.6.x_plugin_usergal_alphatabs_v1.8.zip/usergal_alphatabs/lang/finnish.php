<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'Käyttäjien gallerioiden aakkoselliset välilehdet';
$lang_plugin_usergal_alphatabs['config_description'] = 'Mitä tekee: näyttää välilehdet A:sta Z:aan käyttäjien gallerioiden yläpuolella. Kirjaimia klikkaamalla käyttäjä voi siirtyä suoraan sivulle, joka näyttää kaikki valitulla kirjaimella alkavien käyttäjätunnusten galleriat. Lisäosaa suositellaan vain jos sinulla on todella paljon käyttäjien gallerioita.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Selaa käyttäjätunnusten mukaan';
