<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'Kasutajate galeriide tähestikulised vahekaardid';
$lang_plugin_usergal_alphatabs['config_description'] = 'Mida see teeb: klikitavad vahekaardid A-st Z-ni kasutajagalerii ülaservas võimaldavad külastajatel hüpata lehele, mis kuvab kõikide nende kasutajate galeriid, kelle kasutajanimi algab selle tähega. Plugin on soovitav ainult siis, kui kasutajate galeriide hulk on tõepoolest suur.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Hüppa kasutajanimele';
