<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'Alphabetische Tabs für Benutzer-Galerien';
$lang_plugin_usergal_alphatabs['config_description'] = 'Was dieses Plugin macht: zeigt Tabs von A bis Z am Kopfende der Benutzergalerien an, die angeklickt werden können, um zu den Benutzergalerien mit dem entsprechenden Anfangsbuchstaben zu gelangen. Plugin nur empfehlenswert bei einer wirklich sehr grossen Anzahl von Benutzergalerien.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Verweis per Benutzername';
