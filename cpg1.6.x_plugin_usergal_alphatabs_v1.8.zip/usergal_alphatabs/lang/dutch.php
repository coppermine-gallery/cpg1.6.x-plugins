<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'Gebruiker Galerij Alphabetische rangschikking';
$lang_plugin_usergal_alphatabs['config_description'] = 'Wat het doet: toont de tabs van A tot Z bovenaan de gebruikersgalerij. Hier kunnen de bezoekers klikken om dadelijk een pagina gebruikersgalerijen te krijgen van de gebruiker wiens naam begint met die letter. Het gebruik van de plugin is alleen aan te raden indien je een zeer groot aantal galerijen van gebruikers hebt.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Spring volgens gebruikersnaam';
