<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'Abas Alfabéticas de Galerias de Utilizadores';
$lang_plugin_usergal_alphatabs['config_description'] = 'O que faz: apresenta abas de A a Z no topo das galerias de utilizador onde visitantes podem clicar para saltar directamente para uma página que mostra todas as galerias dos utilizadores cujo nome de utilizador comece por essa letra. Este plugin apenas é recomendado a quem tem um grande número de galerias de utilizador.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Saltar por nome de utilizador';
