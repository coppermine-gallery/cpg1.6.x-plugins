<?php
if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_usergal_alphatabs['config_name'] = 'Schede alfabetiche galleria utente';
$lang_plugin_usergal_alphatabs['config_description'] = 'Cosa fa: mostra schede dalla A alla Z in testa alle gallerie utente, che i visitatori possono cliccare per andare direttamente a una pagina che mostra tutte le gallerie degli utenti il cui nome utente inizia con quella lettera. Plugin consigliato solo se si ha un numero veramente grande di gallerie utente.';
$lang_plugin_usergal_alphatabs['jump_by_username'] = 'Naviga per nome utente';
