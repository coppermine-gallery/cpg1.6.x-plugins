# 
# * Coppermine 1.6.x Plugin - final_extract
# *
# * @copyright	Copyright (c) 2009 Donnovan Bray
# * @license	GNU General Public License version 3 or later; see LICENSE
# *
# * @author		Donnovan Bray (original)
# * @author		ron4mac (23 Dec 2018); version for CPG 1.6.x
# 

INSERT INTO `CPG_final_extract_config` VALUES ('1', '0','0','0','0','0','0','0','0','0','0','0','0','1');
INSERT INTO `CPG_final_extract_config` VALUES ('2', '0','1','0','0','0','0','0','0','0','0','0','0','1');
INSERT INTO `CPG_final_extract_config` VALUES ('3', '0','0','1','1','1','0','0','0','0','1','0','0','0');
INSERT INTO `CPG_final_extract_config` VALUES ('4', '0','1','1','1','1','1','1','1','1','1','1','1','0');