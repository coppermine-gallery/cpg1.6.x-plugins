<?php
/*******************************************************
 Coppermine 1.6.x plugin - FileMove
 *******************************************************
 Copyright (c) 2003-2017 Coppermine Dev Team
 *******************************************************
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.
 *******************************************************
 Ported to CPG 1.6.x June 2017 {ron4mac}
 *******************************************************/

$name = $lang_plugin_FileMove['display_name'];
$author = $lang_plugin_FileMove['author'] . $lang_plugin_FileMove['ported'];
$description = $lang_plugin_FileMove['description'];
$version = "1.4.2";
$plugin_cpg_version = array('min' => '1.6');
$extra_info = $lang_plugin_FileMove['extra_info'];
$install_info = $lang_plugin_FileMove['install_info'];
