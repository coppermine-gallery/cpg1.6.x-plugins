<?php
/**************************************************
  Coppermine 1.6.x Plugin - picture_navigation
  *************************************************
  Copyright (c) 2010-2019 eenemeenemuu
  **************************************************/

$name = 'Picture Navigation';
$description = 'Previous/next picture by clicking next to the picture';
$author = '<a href="http://forum.coppermine-gallery.net/index.php?action=profile;u=24278" rel="external" class="external">eenemeenemuu</a>';
$version = '2.1';
$plugin_cpg_version = array('min' => '1.5');
$extra_info = $install_info = '<a href="http://forum.coppermine-gallery.net/index.php/topic,79600.0.html" rel="external" class="admin_menu">'.cpg_fetch_icon('announcement', 1).'Announcement thread</a>'

//EOF