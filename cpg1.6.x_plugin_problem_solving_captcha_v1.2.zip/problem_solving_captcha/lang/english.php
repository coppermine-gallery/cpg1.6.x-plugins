<?php
/**************************************************
  Coppermine 1.6.x Plugin - Problem Solving CAPTCHA
  *************************************************
  Copyright (c) 2013-2019 eenemeenemuu
**************************************************/

if (!defined('IN_COPPERMINE')) {
    die('Not in Coppermine...');
}

$lang_plugin_problem_solving_captcha['problem_solving_captcha'] = 'Problem Solving CAPTCHA';
$lang_plugin_problem_solving_captcha['description'] = 'Create custom questions your users have to answer';
$lang_plugin_problem_solving_captcha['announcement_thread'] = 'Announcement thread';
$lang_plugin_problem_solving_captcha['question'] = 'Question';
$lang_plugin_problem_solving_captcha['answer'] = 'Answer';

//EOF